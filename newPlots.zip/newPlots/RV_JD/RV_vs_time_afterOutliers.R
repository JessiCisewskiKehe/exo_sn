rv.skew.mean=as.numeric(as.character(skew.normal[,9]))

rv.skew.mode=as.numeric(as.character(skew.normal[,15]))

rv.skew.median=as.numeric(as.character(skew.normal[,18]))

###alpha cent only
#rv.skew.mean=rv.skew.mean*1000
#rv.skew.mode= rv.skew.mode*1000
#rv.skew.median = rv.skew.median*1000
#rv.skew.mean = rv.skew.mean-(-22700.1747 - 0.5307 * ((julian.day.skew-2400000) -55279.109840075726) -1.83e-5 * ((julian.day.skew-2400000) -55279.109840075726)^2)
#rv.skew.mode = rv.skew.mode-(-22700.1747 - 0.5307 * ((julian.day.skew-2400000) -55279.109840075726) -1.83e-5 * ((julian.day.skew-2400000) -55279.109840075726)^2)
#rv.skew.median = rv.skew.median-(-22700.1747 - 0.5307 * ((julian.day.skew-2400000) -55279.109840075726) -1.83e-5 * ((julian.day.skew-2400000) -55279.109840075726)^2)

julian.day.skew=as.double(as.character(skew.normal[,1]))

#dev.new(width = 13, height = 7)
plot(julian.day.skew, rv.skew.mean, col="black", xlab="julian day", ylab="rv", cex=0.5)
points(julian.day.skew, rv.skew.mode, col="blue", cex=0.5)
points(julian.day.skew, rv.skew.median, col="green", cex=0.5)
legend("topleft", c("rv mean","rv median","rv mode"), pch=c(1,1,1),col=c("black","green","blue"), cex=0.5)

d=cbind(julian.day.skew,rv.skew.mean,rv.skew.mode,rv.skew.median)
colnames(d)=c("JD","rv mean","rv median","rv mode")
d=as.data.frame(d)
write.table(d,"LRa01_E2_0165.dat")


head(skew.normal)
